<p align="center">Fullik : javascript fast iterative solver for Inverse Kinematics on three.js<br><br>
is a conversion from java to <a href="https://github.com/FedUni/caliko">Caliko 3D libs</a><br>
Caliko library is an implementation of the FABRIK inverse kinematics (IK) algorithm<br><br>

<a href="http://lo-th.github.io/fullik/">LAUNCH DEMO</a><br></p>